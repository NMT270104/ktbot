package com.example.iot_app.ui.bluetooth.hc05;

import com.example.iot_app.ui.base.IBaseView;

public interface IBluetoothFragment extends IBaseView {
}
