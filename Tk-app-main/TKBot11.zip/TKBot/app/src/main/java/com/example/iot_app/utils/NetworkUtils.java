package com.example.iot_app.utils;

public class NetworkUtils {
}
