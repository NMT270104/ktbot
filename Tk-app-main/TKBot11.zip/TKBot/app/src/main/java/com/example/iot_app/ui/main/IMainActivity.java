package com.example.iot_app.ui.main;

import com.example.iot_app.ui.base.IBaseView;

public interface IMainActivity  extends IBaseView {

    public void setLanguagePref(String language);

    public String getLanguagePref();
}
