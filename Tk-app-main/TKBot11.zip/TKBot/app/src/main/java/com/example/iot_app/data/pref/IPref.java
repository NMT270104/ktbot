package com.example.iot_app.data.pref;

public interface IPref {

    public void setCurrentLanguage(String language);

    public String getCurrentLanguage();
}
