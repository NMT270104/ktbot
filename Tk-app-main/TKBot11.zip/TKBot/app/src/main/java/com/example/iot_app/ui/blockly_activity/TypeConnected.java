package com.example.iot_app.ui.blockly_activity;

public enum TypeConnected {
    HC05,
    HM10
}
