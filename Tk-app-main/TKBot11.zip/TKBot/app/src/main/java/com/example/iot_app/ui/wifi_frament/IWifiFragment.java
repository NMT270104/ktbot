package com.example.iot_app.ui.wifi_frament;

import com.example.iot_app.ui.base.IBaseView;

public interface IWifiFragment extends IBaseView {
}
