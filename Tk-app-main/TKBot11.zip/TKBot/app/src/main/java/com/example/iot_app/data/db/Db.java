package com.example.iot_app.data.db;

import javax.inject.Inject;

public class Db implements IDb {

    @Inject
    public Db() {
    }


}
