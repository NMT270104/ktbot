package com.shashank.sony.fancygifdialoglib;

/**
 * Created by Administrator on 11/20/2017.
 */

public interface FancyGifDialogListener {
    void OnClick();
}
