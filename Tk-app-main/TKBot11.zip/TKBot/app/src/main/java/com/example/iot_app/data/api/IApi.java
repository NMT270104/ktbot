package com.example.iot_app.data.api;


public interface IApi {

}
