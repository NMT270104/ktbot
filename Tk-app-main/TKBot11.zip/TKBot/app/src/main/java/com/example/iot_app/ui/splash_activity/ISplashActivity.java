package com.example.iot_app.ui.splash_activity;

import com.example.iot_app.ui.base.IBaseView;

public interface ISplashActivity extends IBaseView {
    void openMainActivity();
}
