package com.example.iot_app.data.db;



public interface IDb {

}
